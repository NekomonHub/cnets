#!/bin/sh
ipaddr=$(ip -4 addr show wlan0 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1)
if [ -z "$ipaddr" ]; then
  ipaddr=$(ip route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}')
fi

if [ -n "$ipaddr" ]; then
  echo "                      $ipaddr"
  echo "                      $ipaddr"
  echo "                      $ipaddr"
else
  echo "kesalahan tidak diketahui"
fi
