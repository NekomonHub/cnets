import readline from "readline";
import gradient from "gradient-string";
import dns from "dns";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const ask = gradient(['red', 'magenta'])("                   Enter a website URL: ");

rl.question(ask, (url) => {
  const cleanUrl = url.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  dns.lookup(cleanUrl, (err, address) => {
    if (err) {
      console.error(gradient('red', 'magenta')(`❌ Error: ${err.message}`));
    } else {
      console.log(gradient('magenta', 'red')(`                   ${cleanUrl}: ${address}`));
    }
    rl.close();
  });
});
