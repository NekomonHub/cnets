import fetch from "node-fetch";
import fs from "fs";
import gradient from 'gradient-string';
const url = "https://api.ipify.org?format=json";
const logFile = "../iplog.txt";
async function getMyIP() {
  try {
    const res = await fetch(url);
    const data = await res.json();
    const ip = data.ip;
    const waktu = new Date().toLocaleString();
    console.log(gradient(['red','magenta'])(`                 Your Ip : ${ip}`));
    console.log(gradient(['red','magenta'])(`                 Your Ip : ${ip}`));
    console.log(gradient(['red','magenta'])(`                 Your Ip : ${ip}`));
    console.log(gradient(['red','magenta'])(`                 Your Ip : ${ip}`));
    fs.appendFileSync(logFile, `[${waktu}] IP: ${ip}\n`);
  } catch (err) {
    console.error("❌ Gagal ambil IP:", err.message);
  }
}

getMyIP();
